import { SplineScene } from "@/components/ui/splite";

export default function App() {
  return (
    <main
      id="root-container"
      className="fixed inset-0 w-screen h-[100dvh] bg-black flex items-center justify-center overflow-hidden"
    >
      <div
        id="spline-viewport"
        className="w-full h-full flex items-center justify-center relative"
      >
        <SplineScene
          scene="https://prod.spline.design/U5mio-gxbLjNPoD8/scene.splinecode"
          className="w-full h-full"
        />
      </div>
    </main>
  );
}

