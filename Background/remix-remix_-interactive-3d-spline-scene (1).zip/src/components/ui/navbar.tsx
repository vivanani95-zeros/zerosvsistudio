import React from 'react';

export function Navbar() {
  return (
    <nav className="fixed top-6 left-1/2 -translate-x-1/2 z-50 w-[95%] max-w-6xl">
      <div className="flex items-center justify-between px-6 py-3 rounded-full bg-black/40 border border-white/10 backdrop-blur-md relative overflow-hidden group">
        <div className="absolute bottom-0 left-0 h-[1px] w-full bg-gradient-to-r from-transparent via-energy-green/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        
        {/* Left: Logo */}
        <div className="text-white font-semibold tracking-wide text-lg flex items-center gap-2">
          <div className="size-2 rounded-full bg-energy-green shadow-[0_0_8px_rgba(57,255,20,0.8)]" />
          Brand
        </div>

        {/* Right: Links + CTA */}
        <div className="flex items-center gap-8">
          <div className="hidden md:flex items-center gap-6 text-sm font-medium text-neutral-400">
            <a href="#" className="hover:text-energy-green transition-colors duration-300">Home</a>
            <a href="#" className="hover:text-energy-green transition-colors duration-300">Features</a>
            <a href="#" className="hover:text-energy-green transition-colors duration-300">About</a>
            <a href="#" className="hover:text-energy-green transition-colors duration-300">Contact</a>
          </div>
          <button className="px-5 py-2 rounded-full bg-white text-black text-sm font-medium hover:bg-energy-green hover:text-black hover:shadow-[0_0_15px_rgba(57,255,20,0.4)] transition-all duration-300">
            Get Started
          </button>
        </div>
      </div>
    </nav>
  );
}
