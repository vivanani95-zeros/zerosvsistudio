'use client'

import { Suspense, lazy, type CSSProperties } from 'react'
const Spline = lazy(() => import('@splinetool/react-spline'))

interface SplineSceneProps {
  scene: string
  className?: string
  style?: CSSProperties
}

export function SplineScene({ scene, className, style }: SplineSceneProps) {
  return (
    <Suspense 
      fallback={
        <div className="w-full h-full flex items-center justify-center">
          <div className="w-8 h-8 rounded-full border-2 border-emerald-500/20 border-t-emerald-400 animate-spin" />
        </div>
      }
    >
      <Spline
        scene={scene}
        className={className}
        style={style}
      />
    </Suspense>
  )
}

