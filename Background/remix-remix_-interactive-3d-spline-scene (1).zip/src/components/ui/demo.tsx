'use client'

import { SplineScene } from "@/components/ui/splite";
import { Card } from "@/components/ui/card"
import { Spotlight } from "@/components/ui/spotlight"
 
export function SplineSceneBasic() {
  return (
    <Card className="w-full h-[500px] bg-transparent relative overflow-hidden border-none shadow-none">
      <Spotlight
        className="-top-40 left-0 md:left-60 md:-top-20"
        fill="#39FF14"
      />
      
      <div className="flex h-full relative z-10">
        {/* Left content */}
        <div className="flex-1 p-8 flex flex-col justify-center">
          <h1 className="text-4xl md:text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-b from-neutral-50 to-neutral-400">
            3D <span className="text-energy-green drop-shadow-[0_0_10px_rgba(57,255,20,0.5)]">Energy</span> System
          </h1>
          <p className="mt-4 text-neutral-400 max-w-lg leading-relaxed">
            Experience a powerful 3D energy system that reacts in real time — designed for <span className="text-white">high-performance</span> platforms, fast applications, and next-generation digital products.
          </p>
        </div>

        {/* Right content: Energy Chamber Display Panel */}
        <div className="flex-1 relative group p-4 md:p-8">
          <div className="relative w-full h-full rounded-3xl border border-white/10 bg-black/40 backdrop-blur-sm overflow-hidden shadow-2xl transition-all duration-700 group-hover:border-energy-green/30 group-hover:shadow-[0_0_30px_rgba(57,255,20,0.05)]">
            {/* Ambient Chamber Lighting */}
            <div className="absolute inset-0 bg-gradient-to-br from-energy-green/[0.03] via-transparent to-energy-cyan/[0.02] pointer-events-none" />
            <div className="absolute -inset-px bg-gradient-to-t from-energy-green/10 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-1000" />
            
            {/* Scanning Line Effect */}
            <div className="absolute top-0 left-0 w-full h-[1px] bg-energy-green/20 blur-sm animate-[scan_4s_linear_infinite] opacity-0 group-hover:opacity-100" />
            
            {/* Spline Scene with Screen Blending for transparency feel */}
            <div className="w-full h-full mix-blend-screen relative z-10">
              <SplineScene 
                scene="https://prod.spline.design/U5mio-gxbLjNPoD8/scene.splinecode"
                className="w-full h-full"
              />
            </div>

            {/* Tech Corner Accents */}
            <div className="absolute top-4 left-4 size-2 border-t border-l border-energy-green/40 rounded-tl-sm" />
            <div className="absolute top-4 right-4 size-2 border-t border-r border-energy-green/40 rounded-tr-sm" />
            <div className="absolute bottom-4 left-4 size-2 border-b border-l border-energy-green/40 rounded-bl-sm" />
            <div className="absolute bottom-4 right-4 size-2 border-b border-r border-energy-green/40 rounded-br-sm" />
            
            {/* Status Indicator */}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 px-3 py-1 rounded-full bg-black/60 border border-white/5 backdrop-blur-md">
              <div className="size-1.5 rounded-full bg-energy-green animate-pulse shadow-[0_0_8px_rgba(57,255,20,0.8)]" />
              <span className="text-[10px] uppercase tracking-[0.2em] text-neutral-500 font-mono">System Active</span>
            </div>
          </div>
        </div>
      </div>
    </Card>
  )
}
